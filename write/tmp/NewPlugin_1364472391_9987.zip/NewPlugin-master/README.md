NewPlugin
=========

a Simple empty plugin to serve as a template.