<?php
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////** Plugin menu language file **/////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////

// Everything can be translated, even if its in the database. All you need to do is add the original string
// like for instance a menu item that will be newly installed. When you extract your pot file this unused file
// will also be extracted making it possible for the system to have "Some Menu" available in the translation
// list. PHPDevShell surrounds all menus (or whatever you decide) with gettext calls making it possible to
// translate the string.

