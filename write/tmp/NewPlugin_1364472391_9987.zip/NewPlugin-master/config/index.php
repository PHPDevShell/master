<?php
// Directory listing not allowed.
exit('Access Denied!');